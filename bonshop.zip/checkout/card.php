<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <img class="card-img-top" src="holder.js/100x180/" alt=""> 
                <!-- gambare ndukur pastino potrait -->
            </div>
        </div>
        <div class="col-md-">
            <div class="card border-primary">
                <div class="card-body">
                    <h4 class="card-title">Title</h4>
                    <p class="card-text">iki lebokno teks sembarang</p>
                </div>
            </div>
        </div>
    </div>
</div>